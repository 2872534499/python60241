#include "../inc/interface.h"
#include <sys/socket.h>
#include <arpa/inet.h>
using namespace std;

#define SERVER_ADDR "192.168.137.128"
#define PORT 8088

int server_dealLs(Package *pack,int sock)
{
    if (recvPackage(pack,sock) == -1)
    {
        cout << pack->errorCode << endl;
        close(sock);
        return -1;
    }

    DIR* fd = readDir(pack);
    struct dirent *entry;
    while((entry = readdir(fd)) != NULL)
    {
        strcat(pack->file,entry->d_name);
        strcat(pack->file," ");
    }
    if (sendPackage(pack,sock) == -1)
    {
        cout << pack->errorCode << endl;
        close(sock);
        closedir(fd);
        return -1;
    }
    closedir(fd);
    return 1;
}

int server_dealDownload(Package *pack,int sock)
{

    return 1;
}

int server_dealUpload(Package *pack,int sock)
{
    
    return 1;
}

int server_dealFatherDir(Package *pack,int sock)
{
    
    return 1;
}

int server_dealChildDir(Package *pack,int sock)
{
    
    return 1;
}

int server_dealQuitClient(Package *pack,int sock)
{
    
    return 1;
}

int server_dealQuitServer(Package *pack,int sock)
{
    
    return 1;
}

int server_dealClientPackage(Package *pack,int sock)
{

    return 1;
}

int recvClientPackage(Package *pack,int sock)
{
    switch (pack->cmd)
    {
    case LS:
        cout << "处理LS命令" << endl;
        server_dealLs(pack,sock);
        break;

    case UPLOAD:
        cout << "处理UPLOAD命令" << endl;
        server_dealUpload(pack,sock);
        break;

    case DOWNLOAD:
        cout << "处理DOWNLOAD命令" << endl;
        server_dealDownload(pack,sock);
        break;

    default:
        return 0;
    }
    return 1;
}

int main()
{
    cout << "服务端启动" << endl;

    int newsock;
    int sock = createServer(SERVER_ADDR,PORT);
    Package pack;
    struct sockaddr_in client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    while (1)
    {
        if ((newsock = accept(sock,(sockaddr *)&client_addr,&client_addr_len)) < 0)
        {
            perror("accept faild");
            close(sock);
            exit(-1);
        }
        pid_t pid = fork();
        if (pid < 0)
        {
            cout << "fork faild" << endl;
            close(newsock);
            close(sock);
            exit(-1);
        }
        else if(pid == 0)
        {
            cout << "在子进程中 处理请求" << "子进程id: " << getpid() << endl;
            while (1)
            {
                if (recvClientPackage(&pack,newsock) == 0)
                    break;
            }
        }
        else
        {
            cout << "在父进程中 处理连接" << "父进程id: " << getpid() << endl;

        }
    }

    return 0;
}