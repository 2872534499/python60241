
#ifndef __INTERFACE_H__
#define __INTERFACE_H__
#include <iostream>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
using namespace std;

 // 文件规模
#define MAX_FILE_SIZE 512
 // 文件名规模
#define MAX_FILE_NAME_SIZE 32
 // 文件路径规模
#define MAX_FILE_PATH_SIZE 128
enum CMD
{
    LS = 1,      
    UPLOAD,      
    DOWNLOAD,    
    // 查看文件列表
    // 上传文件
    // 下载文件
    FATHERDIR,   // 上一级目录
    SONDIR,      
    // 下一级目录
    QUIT_CLIENT, // 关闭客户端通信
    QUIT_SERVER  // 关闭服务器
};
 // 数据包的结构体
typedef struct
 {
    CMD cmd;                       
    int errorCode;                 
    // 命令类型
    // 命令执行的结果
    char path[MAX_FILE_PATH_SIZE]; // 服务器工作路径
    char name[MAX_FILE_NAME_SIZE]; // 文件名字
    char file[MAX_FILE_SIZE];      
    // 文件内容
} Package;


int createServer(const char* ipv4,int port);

int createClient(const char* ipv4,int port);

FILE *getFp(Package *pack,string name,const char* mode);

int sendPackage(Package *pack,int sock);

int recvPackage(Package *pack,int sock);

int writeFile(FILE *fd,int sock,Package *pack,pthread_mutex_t mutex);

int readFile(FILE *fd,int sock,Package *pack,pthread_mutex_t mutex);

DIR* readDir(Package *pack);

#endif