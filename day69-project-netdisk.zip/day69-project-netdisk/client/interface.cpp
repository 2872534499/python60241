#include <sys/socket.h>
#include <arpa/inet.h>
#include "../inc/interface.h"
using namespace std;




/**
* @brief 创建服务端套接字
* @param ipv4 ipv4地址
* @param port 端口号
*
* @return 成功返回文件描述符 失败返回-1
*/
int createServer(const char* ipv4,int port)
{
    int sock_fd = socket(AF_INET,SOCK_STREAM,0); // 创建服务器连接套接字
    
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    if (inet_pton(AF_INET,ipv4,&server_addr.sin_addr) < 0)
    {
        perror("inet_pton faild");
        close(sock_fd);
        return -1;
    }
    // SO_REUSEPORT 允许多个套接字绑定到同一个地址和端口上。 并非所有操作系统都支持 SO_REUSEPORT。例如，Windows 不支持此选项。
    //  SO_REUSEADDR 允许在同一端口上启动服务器的监听，即使之前的服务器尚未关闭或仍在处理连接。
    int opt = 1;
    setsockopt(sock_fd, SOL_SOCKET, SO_REUSEPORT | SO_REUSEADDR, &opt, sizeof(opt));
    if (bind(sock_fd,(struct sockaddr *)&server_addr,sizeof(server_addr)) < 0)
    {
        perror("bind faild");
        close(sock_fd);
        return -1;
    }

    if (listen(sock_fd,5) < 0)
    {
        perror("listen faild");
        close(sock_fd);
        return -1;
    }
    
    return sock_fd;
}


/**
* @brief 创建客户端套接字
* @param ipv4 ipv4地址
* @param port 端口号
*
* @return 成功返回文件描述符 失败返回-1
*/
int createClient(const char* ipv4,int port)
{
    int sock_fd = socket(AF_INET,SOCK_STREAM,0);

     struct sockaddr_in client_addr;
     client_addr.sin_family = AF_INET;
     client_addr.sin_port = htons(port);
     if (inet_pton(AF_INET,ipv4,&client_addr.sin_addr) < 0)
    {
        perror("inet_pton faild");
        close(sock_fd);
        return -1;
    }

    if (connect(sock_fd,(struct sockaddr *)&client_addr,sizeof(client_addr)) < 0)
    {
        perror("connect faild");
        close(sock_fd);
        return -1;
    }

    cout << "已连接服务器" << endl;
    return sock_fd;
     
    
}

/**
* @brief 发送数据包函数
* @param pack 要发送的数据包
* @param sock 套接字文件描述符
*
* @return 成功返回实际发送到大小,失败返回-1
*/
int sendPackage(Package *pack,int sock)
{
    int ret = send(sock,pack,sizeof(*pack),0);
    if (ret < 0)
    {
        perror("发送失败");
        pack->errorCode = errno;
        return -1;
    }
    return ret;
}

/**
* @brief 接收数据包函数
* @param pack 用于存储接收到的数据包
* @param sock 套接字文件描述符
*
* @return 成功返回实际接收到大小,失败返回-1
*/
int recvPackage(Package *pack,int sock)
{

    int ret = recv(sock,pack,sizeof(*pack),0);
    if (ret < 0)
    {
        perror("接受失败");
        pack->errorCode = errno;
        return -1;
    }
    return ret;
}

/**
* @brief 打开文件获取文件描述符用于操作文件
* @param pack 数据包用于存放执行信息
* @param name 文件名称
* @param mode 文件打开方式
*
* @return 成功返回文件描述符 失败返回NULL 
*/
FILE *getFp(Package *pack,string name,const char* mode)
{
    FILE *fd = fopen(name.c_str(),mode);
    if (!fd)
    {
        perror("文件打开失败");
        pack->errorCode = errno;
        return NULL;
    }
    pack->errorCode = 0;
    return fd;
}

/**
* @brief 写入文件函数
* @param fd 文件描述符
* @param sock 套接字文件描述符
* @param pack 存放文件数据的数据包
* @param mutex 互斥锁 保持操作原子性
*
* @return 成功返回文件描述符 失败返回-1
*/
int writeFile(FILE *fd,int sock,Package *pack,pthread_mutex_t mutex)
{
    int size = 0;
    pthread_mutex_lock(&mutex);
    while (1)
    {
        int ret = recvPackage(pack,sock);
        if (!ret)
        {
            perror("接受失败");
            fclose(fd);
            pthread_mutex_unlock(&mutex);
            return -1;
        }
        size = fwrite(pack->file,1,strlen(pack->file),fd);
        if (size < 0)
        {
            perror("写入文件失败");
            pack->errorCode = errno;
            fclose(fd);
            pthread_mutex_unlock(&mutex);
            return -1;
        }
        else if (size < MAX_FILE_SIZE-1)
        {
            break;
        }
    }
    pack->errorCode = 0;
    pthread_mutex_unlock(&mutex);
    fclose(fd);
    return 1;

}

int readFile(FILE *fd,int sock,Package *pack,pthread_mutex_t mutex)
{
    int size = 0;
    pthread_mutex_lock(&mutex);
    while (1)
    {
        size = fread(pack->file,1,MAX_FILE_SIZE-1,fd);
        if (size < 0)
        {
            perror("读取失败");
            pack->errorCode = errno;
            fclose(fd);
            pthread_mutex_unlock(&mutex);
            return -1;
        }
        sendPackage(pack,sock);
        if (size < MAX_FILE_SIZE-1)
        {
            cout << "读取文件完成" << endl;
            break;
        }
    }
    pthread_mutex_unlock(&mutex);
    pack->errorCode = 0;
    fclose(fd);
    return 1;
}

DIR* readDir(Package *pack)
{
    DIR* fd = opendir(pack->path);
    if (!fd)
    {
        perror("目录打开失败");
        pack->errorCode = errno;
        closedir(fd);
        return NULL;
    }

    pack->errorCode = 0;
    return fd;
}

// int main()
// {
//     Package pack = {LS,0,"/","name","hello world"};
//     DIR* fd = readDir(&pack,"/home/zheng/cc++");
//     struct dirent *entry;
//     while ((entry = readdir(fd)) != NULL)
//     {
//         cout << entry->d_name << endl;
//     }
//     closedir(fd);
// }

