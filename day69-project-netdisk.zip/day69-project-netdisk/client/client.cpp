#include "../inc/interface.h"
#include <sys/socket.h>
#include <arpa/inet.h>
using namespace std;


#define SERVER_ADDR "192.168.137.128"
#define PORT 8088

pthread_mutex_t mutex;

void printMenu(string currentPath)
{
    cout << "当前服务端所在路径: " << currentPath << endl;
     std::cout << "1.查看当前目录下的文件" << std::endl;
    std::cout << "2.上传文件（暂不支持文件夹）" << std::endl;
    std::cout << "3.下载文件（暂不支持文件夹）" << std::endl;
    std::cout << "4.返回上一级目录" << std::endl;
    std::cout << "5.进入子目录" << std::endl;
    std::cout << "6.关闭客户端通信" << std::endl;
    std::cout << "7.关闭服务器" << std::endl;
    std::cout << "---------------------------------------" << std::endl;
}

int getServerResult(Package *pack,int sock)
{
    if (sendPackage(pack,sock) == -1)
    {
        cout << pack->errorCode << endl;
        close(sock);
        return -1;
    }
    return 1;
}

int client_dealLs(Package *pack,int sock)
{
    pack->cmd = LS;
    if (getServerResult(pack,sock) == -1)
    {
        close(sock);
        return -1;
    }
    recvPackage(pack,sock);
    cout << pack->file << endl;
    strcpy(pack->file,"");
    return -1;
}

int client_dealDownload(Package *pack,int sock)
{
    pack->cmd = DOWNLOAD;
    cout << "输入要下载的文件" << endl;
    cin >> pack->name;
    if (getServerResult(pack,sock) == -1)
    {
        close(sock);
        return -1;
    }
    FILE *fd = getFp(pack,string(pack->name),"w+");
    if (writeFile(fd,sock,pack,mutex) == -1)
    {
        cout << pack->errorCode << endl;
        return -1;
    }
    return 1;
}

int client_dealUpload(Package *pack,int sock)
{
    
    return 1;
}

int client_dealFatherDir(Package *pack,int sock)
{
    
    return 1;
}

int client_dealChildDir(Package *pack,int sock)
{
    
    return 1;
}

int client_dealQuitClient(Package *pack,int sock)
{

    return 1;   
}

int client_dealQuitServer(Package *pack,int sock)
{
    
    return 1;
}

int client_dealClientPackage(Package *pack,int sock)
{

    return 1;
}

int dealUser(Package *pack,int sock,int *option,string currentPath)
{
    if (*option != 1)
        printMenu(currentPath);
    cin >> *option;
    if (option == 0)
    {
        return 0;
    }
    switch (*option)
    {
    case LS:
        cout << "处理LS命令" << endl;
        client_dealLs(pack,sock);
        break;

    case UPLOAD:
        cout << "处理UPLOAD命令" << endl;
        client_dealUpload(pack,sock);
        break;

    case DOWNLOAD:
        cout << "处理DOWNLOAD命令" << endl;
        client_dealDownload(pack,sock);
        break;
    
    default:
        break;
    }
    if (*option != 1)
        system("clear");
    return 1;
}


int main()
{
    cout << "客户端启动" << endl;
    if (pthread_mutex_init(&mutex,NULL))
    {
        perror("互斥锁初始化失败");
        exit(-1);
    }
    string currentPath = "/home/zheng/cc++/day69-project-netdisk/filePath";
    Package pack;
    memset(&pack,0,sizeof(pack));
    strcpy(pack.path,currentPath.c_str());
    int sock = createClient(SERVER_ADDR,PORT);
    int option = 0;
    while (1)
    {
        if (!dealUser(&pack,sock,&option,currentPath))
        {
            break;
        }
    }

    return 0;
}